# spring-rest-vdsi

mydb.cpc3a6hofcbs.ap-south-1.rds.amazonaws.com:3306