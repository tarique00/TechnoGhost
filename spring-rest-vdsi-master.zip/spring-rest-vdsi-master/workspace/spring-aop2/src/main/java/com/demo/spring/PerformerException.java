package com.demo.spring;

public class PerformerException extends Exception {

}
