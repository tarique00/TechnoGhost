package com.demo.spring;

import java.util.List;

public interface Dao {
public String save(List<Emp> emps);
}
